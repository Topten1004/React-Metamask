import React, { Component } from 'react';




export default class isMetaMask extends Component{
    
    constructor(props){
        super(props);

    }
    render(){
        return(
            <div>
                <p>Install MetaMask to Sign in
                
                </p>
            </div>
        )
    }
}