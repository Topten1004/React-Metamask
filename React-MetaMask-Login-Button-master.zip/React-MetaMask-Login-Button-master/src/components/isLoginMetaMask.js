import React, { Component } from 'react';



export default class isLoginMetaMask extends Component {

    constructor(props) {
        super(props)
    }

    render() {
        return (
            <div>
                <p>Login into MetaMask
            <br />
                </p>
            </div>

        )
    }
}