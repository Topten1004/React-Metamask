import React, { Component } from 'react';
import Web3 from 'web3';


export default class Login extends Component {

    constructor(props) {
        super(props);
    }


    render() {
        return (
            <div>

                <p>Signed in with MetaMask
                    <br />
                </p>
            </div>
        )
    }
}