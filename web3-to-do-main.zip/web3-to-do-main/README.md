# web3-to-do
A simple web3 CRUD todo app


## Server 
> npx hardhat run scripts/deploy.js --network goerli

> npx hardhat run scripts/deploy.js --network localhost

> npx hardhat node

> localhost chainId: 0x539

## Client
> npm install

> npm run start
