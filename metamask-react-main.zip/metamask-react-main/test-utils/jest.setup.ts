afterEach(() => {
    jest.clearAllMocks();
});