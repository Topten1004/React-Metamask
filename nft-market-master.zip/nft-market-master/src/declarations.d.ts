declare module 'jazzicon'
